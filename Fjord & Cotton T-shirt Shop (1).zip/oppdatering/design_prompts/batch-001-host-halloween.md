# Design-prompter — batch 001 (Recraft V3-versjon)

> Felles oppskrift, tekniske krav og fargeregler: `00-promptmal.md`. Les den først.

**Dato:** 28. juli 2026 · **Kolleksjon:** Høst (7 stk) + Halloween (3 stk)

Omskrevet for **Recraft V3** med vektoreksport. Da slipper du oppskalering helt — SVG er skarp
på 4500×5400 uansett.

## Slik bruker du dem

1. Gå til Recraft → velg **Vector Illustration** som modus (ikke Raster).
2. Sett stil til den som er nevnt i prompten (Recraft har navngitte stiler i sidepanelet).
3. Lim inn prompten. Generer 4 varianter, velg den beste.
4. Eksporter som **SVG**. Har du bruk for PNG til Gelato: eksporter SVG først, konverter til
   PNG 4500×5400 px / 300 dpi med transparent bakgrunn.
5. Filnavn: `001-nordavind.svg` — samme nummer som under. Send meg filene.

**Unntak:** 002 og 007 er typografi med Æ og Å. Recraft skriver ofte disse feil. Kjør dem i
**Ideogram v4** i stedet, sjekk bokstavene nøye, og oppskaler resultatet.

**Recraft-spesifikt som er lagt inn i alle promptene:** flat vector, ingen gradienter, begrenset
palett, transparent bakgrunn. Recraft respekterer fargebegrensninger bedre enn de fleste — bruk
det, færre farger trykker skarpere og ser dyrere ut.

**Fellesregler:** ingen tekst i bildene (unntatt 002 og 007), ingen logoer eller merkevarer, ingen
gjenkjennelige personer, ingen kommunevåpen eller riksvåpen.

---

## HØST

### 001 — Nordavind
**Tema:** Natur · **Recraft-stil:** Vector Illustration → Flat Design

> Flat vector illustration: wind-bent pine trees in silhouette on a bare hillside. Exactly four
> flat colours — deep charcoal, muted rust, pale sand, slate blue. Bold simplified shapes, clean
> closed paths, no gradients, no strokes, no fine detail. Centred square composition on a fully
> transparent background.

### 002 — Regnvær
**Tema:** Typografi · **Kjør i Ideogram v4, ikke Recraft**

> Bold condensed typographic lockup, the Norwegian word "REGNVÆR" stacked across three heavy lines.
> Vintage letterpress style with worn ink edges. Two colours only: off-black and muted amber.
> Spell it exactly R, E, G, N, V, Æ, R — the sixth character is the Norwegian letter Æ. Flat, no
> gradients, transparent background, no other text.

### 003 — Sopptur
**Tema:** Natur · **Recraft-stil:** Vector Illustration → Engraving

> Flat vector botanical plate: four different forest mushrooms arranged in a two-by-two grid,
> drawn as fine engraved linework with flat colour fills behind the lines. Palette limited to four
> colours — ochre, moss green, warm brown, cream. 1900s field-guide aesthetic. Clean vector paths,
> transparent background, no text, no labels.

### 004 — Siste Kaffe
**Tema:** Humor · **Recraft-stil:** Vector Illustration → Bold Shapes

> Flat vector illustration: an enamel camping mug on a mossy rock with a single small bird perched
> on the handle, three curls of steam rising. Exactly four colours — rust, cream, forest green,
> charcoal. Thick uniform outlines, mid-century printed poster style, no gradients. Centred on a
> transparent background, no text.

### 005 — Mørketid
**Tema:** Abstrakt · **Recraft-stil:** Vector Illustration → Geometric

> Flat vector geometric composition: a large circle partly covered by four overlapping horizontal
> bands, reading as a sun sinking behind layered mountains. Three flat colours only — burnt orange,
> deep navy, warm cream. Hard geometric edges, perfectly flat fills, no gradients, no texture.
> Square, centred, transparent background.

### 006 — Hjemover
**Tema:** Byliv · **Recraft-stil:** Vector Illustration → Flat Design

> Flat vector illustration: a lit tram window seen from outside on a rainy evening, warm light
> spilling out, diagonal rain streaks across the glass. Simplified rectangular geometry, exactly
> four colours — wet navy, warm yellow, charcoal, pale grey. No gradients, no photographic detail.
> Transparent background, no text, no route numbers.

### 007 — Grå Uke
**Tema:** Typografi · **Kjør i Ideogram v4, ikke Recraft**

> Minimal typographic mark: the Norwegian phrase "GRÅ UKE" in a narrow uppercase grotesk, wide
> letter spacing, a single thin horizontal rule above and below. One colour only, warm off-white,
> for printing on a dark shirt. Spell it exactly G, R, Å, space, U, K, E — the third character is
> the Norwegian letter Å. Crisp flat edges, transparent background, no other text.

---

## HALLOWEEN

### 008 — Nattravn
**Tema:** Natur · **Recraft-stil:** Vector Illustration → Bold Shapes

> Flat vector illustration: an owl rendered entirely as a solid silhouette in front of a full moon
> drawn as a single flat disc. Three colours only — black, bone white, deep violet. Bold graphic
> shapes, no feather detail, no gradients, clean closed paths. Centred, transparent background,
> no text.

### 009 — Draug
**Tema:** Retro · **Recraft-stil:** Vector Illustration → Retro

> Flat vector illustration in 1970s horror-paperback style: a hooded figure standing in a small
> wooden boat on flat black water, seen from behind, layered fog bands. Four colours — sea green,
> bone, black, one blood-red accent. Stylised and flat, no photorealism, no visible face, no
> gradients. Transparent background, no text.

### 010 — Spøkelsestime
**Tema:** Humor · **Recraft-stil:** Vector Illustration → Flat Design

> Flat vector illustration: three simple rounded ghosts floating in a row at slightly different
> heights and sizes, thick uniform outlines, simple dot eyes, friendly rather than scary. Three
> colours only — bone white, charcoal, soft orange. Mid-century children's book style, flat fills.
> Transparent background, no text.

---

## Mockups

Gelato lager dem. Én produktmal definerer trykkplassering og flatlay-scene for alle seks
farger, og hvert design får mockups automatisk etter publisering. Du fotograferer
ingenting og komponerer ingenting.

Oppsettet av malen står i `design_handoff_fjord_cotton/05-admin-upload.md`, steg for steg
i `LANSERINGSPLAN.md` DEL 5.

---

## Neste batch

Jul må starte i oktober. Si fra hvis en bestemt stil selger bedre, så vekter jeg neste batch dit.
