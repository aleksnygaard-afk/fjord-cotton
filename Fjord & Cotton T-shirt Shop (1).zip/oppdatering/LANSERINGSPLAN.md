# Lanseringsplan — Fjord & Cotton

Følg stegene i rekkefølge. Ikke hopp framover: hvert steg avhenger av det forrige.
Kryss av underveis.

---

## DEL 1 — E-post (15 minutter)

Butikken har fire plassholdere som må erstattes. Alt annet stopper uten denne.

1. Logg inn på one.com → Kontrollpanel → E-post
2. Opprett `post@dittdomene.no` (eller `hei@`)
3. Sett opp videresending til din vanlige e-post, ellers glemmer du å sjekke den
4. Send en test-e-post til adressen og bekreft at den kommer fram
5. Send meg adressen — jeg fyller den inn i butikken

---

## DEL 2 — Supabase (30 minutter)

1. Gå til supabase.com → New project
2. **Region: EU (Frankfurt eller Stockholm).** Kan ikke endres senere
3. Velg et sterkt databasepassord og lagre det
4. Når prosjektet er klart: SQL Editor → lim inn hele `02-data-model.sql` → Run
5. Kjør deretter `02b-seed.sql`, så `02c-catalog-facets.sql`. **Alle tre, i rekkefølge.**
   Mangler den siste, kaster forsiden 500-feil: `Could not find the function public.catalog_facets`
6. Table Editor → bekreft at tabellene `designs`, `variants`, `orders` finnes
7. Bekreft grunndata: 7 rader i `themes`, 8 i `collections`, 6 i `garment_colors`,
   7 i `garment_sizes` (XS, S, M, L, XL, XXL, 3XL)
8. Settings → API → kopier `Project URL`, `anon public` OG `service_role` til `.env`

**Ikke gå videre før du får ut data fra basen lokalt.**

---

## DEL 3 — GitHub (15 minutter)

1. Åpne `.gitignore` og bekreft at `.env` og `.env.local` står der.
   **Sjekk dette før du pusher. Nøkler i git kan ikke fjernes helt igjen.**
2. I prosjektmappen:
   ```
   git init
   git add .
   git commit -m "Første versjon"
   ```
3. github.com → New repository → navn `fjord-cotton` → **Private**
4. Kjør de tre kommandoene GitHub viser under "push an existing repository"
5. Last siden på nytt og bekreft at filene er der — men at `.env` IKKE er der

---

## DEL 4 — Vercel (30 minutter)

1. vercel.com → logg inn med GitHub
2. Add New → Project → velg `fjord-cotton`
3. Framework Preset skal si Next.js av seg selv. Ikke endre build-innstillinger
4. **Environment Variables — gjør dette før du deployer.** Lim inn hver variabel fra `.env`,
   og huk av Production, Preview og Development for alle:
   ```
   NEXT_PUBLIC_SITE_URL
   NEXT_PUBLIC_SUPABASE_URL        ← må ha NEXT_PUBLIC_-prefiks
   NEXT_PUBLIC_SUPABASE_ANON_KEY   ← anon-nøkkelen, ikke service_role
   SUPABASE_URL
   SUPABASE_SERVICE_ROLE_KEY
   DINTERO_ACCOUNT_ID=T11116836      ← test ennå
   DINTERO_CLIENT_ID
   DINTERO_CLIENT_SECRET
   DINTERO_PROFILE_ID
   GELATO_API_KEY
   GELATO_TEMPLATE_ID
   RESEND_API_KEY
   ```
5. Deploy
6. **Endrer du en `NEXT_PUBLIC_`-variabel senere: Redeploy MED HAKEN AV på
   «Use existing Build Cache».** De bakes inn ved bygging, ikke ved kjøring.
   Redeployer du med cache, leses de gamle verdiene og feilen står
7. Settings → Functions → Region → **Frankfurt (eu-central-1)**. Redeploy etterpå
7. Åpne `fjord-cotton.vercel.app` og klikk gjennom hele butikken

Feiler bygget: les loggen fra toppen. Nesten alltid en manglende miljøvariabel.
Bygget grønt men siden viser «Application error»: feilen er i kjøretid, ikke bygging.
Vercel → **Logs** (ikke Deployments) → last siden på nytt → les den røde linjen.

---

## DEL 5 — Gelato og produktmalen (1–2 timer)

**Gjør denne før DEL 6.** Malen er det som lager produktbildene dine — du fotograferer
ingenting selv.

1. gelato.com → opprett konto (selvbetjent, gratis)
2. **Finn produksjonslokasjon for norske ordre.** Sier den ikke Norge, må teksten
   "Trykkes og sendes fra Oslo" endres i butikken
3. Oppgrader til **Gelato+**. Mockup Studio og nedlasting av mockups er ikke på gratisplanen.
   Dette er den ene faste kostnaden du ikke kommer rundt
4. Templates → ny mal med 220 g kammet bomull unisex crewneck:
   - nøyaktig seks farger: hvit, sort, sand, salvie, marine, rust
   - størrelser XS–3XL
   - trykkplassering foran, 100 px sikkerhetsmarg, samme brystbredde på alle farger
5. **Velg én flatlay-scene og bruk den på alle seks fargene.** Blandede scener får
   katalogen til å se ut som et bruktmarked. Hopp over livsstils- og AI-scener her
6. Kopier **Template ID** til `GELATO_TEMPLATE_ID` i Vercel og `.env`
7. Seed UID-ene med skriptet — **ikke skriv dem inn manuelt:**

   ```bash
   cd design_handoff_fjord_cotton/scripts
   GELATO_API_KEY=din_nokkel GELATO_TEMPLATE_ID=din_mal node seed-gelato-uids.mjs > uids.sql
   ```

   Åpne `uids.sql` og lim innholdet inn i Supabase SQL Editor. Seks `update`-linjer.
   Skriptet stopper hvis en farge eller størrelse mangler i malen, og SQL-en ruller
   tilbake hvis en farge står uten UID. Klager det på et fargenavn, legg navnet inn i
   `COLOR_MAP` øverst i skriptet og kjør på nytt
8. Kjør `02d-gelato-mockups.sql`, deretter `02e-design-colors.sql` i Supabase
9. Sjekk fraktsatsene under Shipping mot dine priser (0 / 59 / 149 kr)
10. Bestill **én prøveskjorte til deg selv**. Se på trykket før du selger det

---

## DEL 6 — Design inn i katalogen (1 time)

Dintero avviser butikker uten reelle produkter. Du trenger minst 10–20 publiserte design.

1. Generer de ti designene fra `batch-001` i Recraft V3 — velg **Vector**, ikke raster
2. Eksporter til PNG 4500×5400 px, 300 dpi, **transparent bakgrunn**
3. **Sjekk hver fil mot en mørk bakgrunn.** En usynlig hvit bakgrunn blir et hvitt
   rektangel på en sort skjorte. Vanligste feilen i bransjen, og Gelato fanger den ikke
4. Last opp via admin-siden: tittel, tema, kolleksjon og **fargevalg** per design.
   Lys / Mørk / Alle — et sort motiv er usynlig på sort skjorte
5. Publiser. Designene er `pending` til Gelato har laget mockups — de vises ikke i
   butikken før bildene er inne, med vilje
6. Vent noen minutter, last butikken på nytt, og bekreft at bildene og tellingene stemmer

Blir en rad stående på "Mangler mockup" i over et kvarter, har webhooken ikke kommet.
Cron-jobben skal hente produktet direkte som reserveløsning — se `05-admin-upload.md`.

---

## DEL 7 — Dintero i testmodus (1–2 timer)

1. Bekreft at `.env` bruker `T11116836` og testnøklene
2. Gjør et testkjøp i butikken hele veien gjennom kassen
3. Sjekk i Supabase at ordren finnes med status `paid`
4. Sjekk at Gelato-ordren ble opprettet
5. Sjekk at kvitterings-e-posten kom
6. **Test at webhooken virker på Vercel, ikke bare lokalt.** `callback_url` må peke på
   det ekte domenet, ikke localhost
7. Prøv å manipulere prisen fra nettleseren og bekreft at serveren avviser den

---

## DEL 8 — Juridisk (1 time)

1. Send meg e-postadressen så plassholderne fylles inn
2. Bekreft at de fire sidene er nåbare på ekte URL-er:
   `/salgsbetingelser`, `/angrerett`, `/frakt`, `/personvern`
3. Last ned angrerettskjemaet fra forbrukertilsynet.no og legg det ut som PDF
4. Legg skjemaet som vedlegg i ordrebekreftelsen
5. **Mva:** er registreringen ikke godkjent ennå, sett `VAT_REGISTERED=false` og
   fjern mva-linjene fra kurv, kasse og kvittering

---

## DEL 9 — Domene (30 minutter + venting)

1. Vercel → Settings → Domains → legg til domenet
2. one.com → DNS-innstillinger:

   | Type | Navn | Verdi |
   |---|---|---|
   | A | @ | `76.76.21.21` |
   | CNAME | www | `cname.vercel-dns.com` |

3. Slett one.coms egne A/CNAME-oppføringer for `@` og `www`
4. **Ikke rør MX-oppføringene** — de styrer e-posten din
5. Vent på SSL. Minutter til et par timer
6. Oppdater `NEXT_PUBLIC_SITE_URL` i Vercel til det ekte domenet og redeploy

---

## DEL 10 — Dintero-søknad

Send inn først når alt over er ferdig — de klikker seg inn på siden og sjekker.

1. Fullfør aktiveringen i Dintero (5–10 min ifølge dem)
2. Velg betalingsmetoder: Vipps, Klarna, kort
3. Vipps og Klarna godkjennes separat og kan ta noen dager

---

## DEL 11 — Go live

1. Bytt til `DINTERO_ACCOUNT_ID=P11116836` og produksjonsnøklene i Vercel.
   **Kun som miljøvariabler, aldri i koden**
2. Redeploy
3. **Kjøp én skjorte av deg selv med Vipps, med ekte penger.** Verifiser:
   - Ordren blir `paid` i basen
   - Gelato mottar og trykker
   - Kvittering med org.nr og mva-beløp kommer på e-post
   - Sporingslenken fungerer
4. Refunder kjøpet. Da har du testet refusjonsflyten før en kunde trenger den
5. Sett opp bokføringseksport til Fiken eller Tripletex

---

## Etter lansering — den daglige rutinen

1. Generer ti design (be meg om ny promptbatch)
2. Last opp via admin, sett tema og kolleksjon — mockups kommer fra Gelato av seg selv
3. Publiser eller planlegg til en dato
4. Sjekk innboksen for retur- og reklamasjonshenvendelser

Sesongregelen: publiser alltid før sesongen. Jul må ut i oktober, påske i februar.

---

## Feilsøking

| Symptom | Årsak |
|---|---|
| Bygget feiler på Vercel | Manglende miljøvariabel. Les loggen fra toppen |
| Siden laster men er tom | Feil Supabase-nøkkel, eller ingen `published` rader |
| Ordre blir aldri `paid` | Webhook peker på localhost eller preview-URL |
| Gelato får ingen ordre | Feil `productUid`, eller jobben kjørte før ordren var `paid` |
| Domenet viser one.com-side | Gamle A/CNAME-oppføringer er ikke slettet |
| Bildene er uskarpe på trykk | Under 300 dpi. Eksporter fra SVG, ikke oppskaler PNG |
