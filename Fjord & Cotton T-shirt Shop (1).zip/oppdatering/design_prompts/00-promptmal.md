# Promptmal — fast oppskrift for alle design

Bruk denne malen for hver batch fra nå. Den er bygd rundt to faste ting som ikke skal
endres: **Gelatos trykkspesifikasjon** og **den ene trykkplasseringen i produktmalen**.

Fordelen med å låse begge: hver fil du lager passer rett inn, mockups blir like på tvers
av hele katalogen, og du trenger aldri justere plassering per design.

---

## Det tekniske som ligger fast

| | |
|---|---|
| Lerret | 4500 × 5400 px, stående (5:6) |
| Oppløsning | 300 dpi |
| Format | PNG-24 med alfakanal |
| Fargerom | sRGB |
| Bakgrunn | Helt transparent |
| Sikkerhetsmarg | 100 px inn fra alle kanter |
| Trykkplassering | Foran, brystsentrert — definert én gang i Gelato-malen |
| Fysisk størrelse | ca. 30 × 36 cm på trykket |

Plasseringen bestemmes av malen, ikke av filen. Filen skal derfor **alltid** fylle
lerretet på samme måte — er motivet lite i én fil og stort i en annen, ser katalogen
ujevn ut selv om plasseringen teknisk er identisk.

**Komposisjonsregelen:** motivet skal dekke 80–90 % av lerretets bredde, optisk sentrert,
med luft inn til sikkerhetsmargen. Ikke fyll ut til kanten, og ikke la motivet flyte
alene midt i et stort tomt felt.

---

## Prompt-malen

Lim inn dette i Recraft og bytt bare ut de to feltene i klammeparentes.

> Flat vector illustration: **[MOTIV — én setning, konkret, ingen stemningsord]**.
> Exactly **[3 eller 4]** flat colours — **[fargeliste]**. Bold simplified shapes, clean
> closed paths, no gradients, no strokes, no texture, no fine detail. Vertical composition
> filling the frame with even margins, subject optically centred. Fully transparent
> background. No text, no logos, no signature, no frame, no border.

**Innstillinger i Recraft:**

1. Modus: **Vector Illustration** — aldri Raster
2. Stil: velg fra sidepanelet, og noter hvilken du brukte i batch-filen
3. Sideforhold: **2:3 eller 3:4 stående** (nærmest 5:6 Recraft tilbyr)
4. Generer 4 varianter, velg én
5. Eksporter **SVG**

## SVG → PNG

SVG-en er oppløsningsuavhengig, så konverteringen er der kravene faktisk oppfylles.

```
Bredde   4500 px
Høyde    5400 px
DPI      300
Bakgrunn transparent
Format   PNG-24
```

Har SVG-en et annet sideforhold enn 5:6, skalér til å passe **høyden** og sentrer
horisontalt. Ikke strekk. Ikke beskjær.

**Kontroller hver fil før opplasting:** åpne den mot en sort bakgrunn. Ser du et hvitt
eller lyst rektangel rundt motivet, har Recraft lagt inn en bakgrunn — den må fjernes.
Dette er den vanligste og dyreste feilen i print-on-demand, og Gelato fanger den ikke.

---

## Fargeregler

Tre eller fire flate farger. Ikke fem, ikke gradienter. Færre farger trykker skarpere,
holder seg bedre gjennom vask, og ser dyrere ut.

**Det viktige med seks skjortefarger:** butikken tilbyr hvit, sort, sand, salvie, marine
og rust. Et design i sort silhuett er usynlig på sort skjorte. Et bendelys design
forsvinner på hvit.

Velg derfor én av tre strategier per design, og skriv hvilken i batch-filen:

| Strategi | Palett | Selges i |
|---|---|---|
| **Lys-trygg** | mellomtoner + mørke, ingen nesten-hvitt | hvit, sand, salvie |
| **Mørk-trygg** | benhvit, oker, dempet — ingen nesten-sort | sort, marine, rust |
| **Nøytral** | mellomtoner, minst 30 % kontrast mot alle seks | alle seks |

Nøytral er vanskeligst å treffe og verdt å sikte mot — det gir 42 varianter i stedet for 21.

Strategien settes ved opplasting — tre knapper på admin-raden, med en prikkerad som viser
hvilke av de seks fargene designet faktisk selges i. Migrasjonen er
`02e-design-colors.sql`; `generate_variants()` leser fargevalget, så et begrenset design
får 21 varianter i stedet for 42.

Endrer du strategien senere, kjør `generate_variants()` på nytt. Varianter som ikke
lenger gjelder deaktiveres, men slettes aldri — gamle kvitteringer må fortsatt kunne
slås opp.

---

## Faste forbud

Gjelder alle prompter, hver gang:

- Ingen tekst i bildet — med mindre designet **er** typografi, og da kjøres det i Ideogram v4
- Ingen logoer, merkevarer eller varemerker
- Ingen gjenkjennelige personer eller kjendislikhet
- Ingen kommunevåpen og ikke riksvåpenet — beskyttet i Norge
- Ingen opphavsrettsbeskyttede figurer
- Ingen ramme, kantlinje eller signatur

Ta minuttet det koster å se gjennom hver fil. En nedtaking etter hundre salg er dyrere.

---

## Typografidesign

Recraft skriver `Æ Ø Å` feil ofte nok til at det ikke er verdt å prøve. Kjør typografi i
**Ideogram v4** i stedet, stav bokstavene ut enkeltvis i prompten, og kontroller hver
bokstav i resultatet.

> Bold condensed typographic lockup, the Norwegian word **"[ORD]"** on **[antall]** stacked
> lines. **[stil]**. Two colours only: **[to farger]**. Spell it exactly
> **[B, O, K, S, T, A, V]** — the **[n]**-th character is the Norwegian letter **[Æ/Ø/Å]**.
> Flat, no gradients, transparent background, no other text.

Ideogram gir raster, så her trengs oppskalering til 4500 px bredde før PNG-eksport.

---

## Loggfør hver prompt

Skriv `prompt` og `generator` på designraden ved opplasting. Blir et design utfordret av
en rettighetshaver, må du kunne vise hva som produserte det. Admin-siden gjør dette
automatisk hvis feltene finnes — det er én kolonne, ikke en funksjon.
